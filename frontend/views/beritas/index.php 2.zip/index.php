

<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel frontend\models\BeritasSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Berita Kehilangan/ Ditemukan';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="beritas-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php  echo $this->render('_search', ['model' => $searchModel]); ?>
<!--     <p>
        <?= Html::a('Buat Berita', ['create'], ['class' => 'btn btn-success']) ?>
    </p> -->
<?php Pjax::begin(); ?>    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
/*        'rowOptions'=>function($model){
            if ($model->status_ditemukan=='3')
            {
                return ['class'=>'btn-success'];
            }

            else {
               // return ['class'=>'btn-success'];
            }
        },*/

        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'berita_id',

/*            [
            'attribute'=>'user_id',
            'value'=>'user.nama_lengkap',
            ], */


            [
                'attribute' => 'jenis_berita',
                'contentOptions' => ['class' => 'text-center'],
                'headerOptions' => ['class' => 'text-center'],
            ],


            [
                'attribute'=>'category_id',
                'value'=>'category.category_name',
                'contentOptions' => ['class' => 'text-center'],
                'headerOptions' => ['class' => 'text-center'],                         
            ], 
            //'judul_berita',
            [
                'attribute' => 'judul_berita',
                'format' => 'html',
                'label' => 'Judul Berita',
                'headerOptions' => ['class' => 'text-center'],               
                'value' => function ($model) {
                    if (strlen($model->judul_berita)>=25){
                        return substr(($model->judul_berita),0,25).'...';
                    }

                    else {
                        return ($model->judul_berita);
                    }
                },

            ],           

 
            [
                'attribute' => 'deskripsi_berita',
                'format' => 'html',
                'label' => 'Deskripsi',
                'headerOptions' => ['class' => 'text-center'],
                'value' => function ($model) {
                    if (strlen($model->deskripsi_berita)>40){
                        return substr(($model->deskripsi_berita),0,40).'...';
                    }

                    else {
                        return ($model->deskripsi_berita);
                    }
                },

            ],

            [
                'attribute' => 'updated_at',
                'contentOptions' => ['class' => 'text-center'],
                'headerOptions' => ['class' => 'text-center'],
            ],


/*            [
                'attribute' => 'berita_id',
                'format' => 'html',
                'label' => 'Foto',
                'value' => function ($model) {
                    if ($model->documents->filename){
                        return Html::img($model->documents->filename,['width' => '100px']);                        
                    }
                    else {
                        return Html::img('uploads/empty.jpg',['width' => '100px']);
                    }
                },
            ],
*/


/*            [
                'attribute' => 'status_ditemukan',
                'format' => 'html',
                'value' => function($model){
                        if ($model->status_ditemukan==0){
                            return 'Belum Ditemukan'; 
                        }
                        elseif ($model->status_ditemukan==1){
                            return 'Telah Ditemukan'; 
                        }
                        elseif ($model->status_ditemukan==2){
                            return 'Belum diambil oleh pemiliknya'; 
                        }                     
                        else {
                            return 'Telah diambil oleh pemiliknya'; 
                        }   
                }
            ],
*/

            [
                'attribute' => 'berita_id',
                'format' => 'html',
                'label' => 'Foto',   
                'contentOptions' => ['class' => 'text-center'],
                'headerOptions' => ['class' => 'text-center'],
                'value' => function($model){
                        $beritaDocuments = (new \yii\db\Query())
                            ->select('filename')
                            ->from('documents')
                            ->where(['berita_id'=>$model->berita_id])
                            ->scalar();
                       if ($beritaDocuments){
                            return Html::img(Yii::$app->request->baseUrl.'/'.$beritaDocuments,['height' => '50px']);  
                        }
                        else {
                            return Html::img(Yii::$app->request->baseUrl.'/'.'uploads/empty.jpg',['height' => '50px']);
                        }

                }
            ],


            // 'email:email',
            // 'hub_email:email',
            // 'no_telp1',
            // 'no_telp2',
            // 'pin_bb',
            // 'hub_wa',
            // 'status',
            // 'province_id',
            // 'regency_id',
            // 'district_id',
            // 'village_id',
            // 'created_at',
            // 'updated_at',

            //['class' => 'yii\grid\ActionColumn'],

            [
                'class' => 'yii\grid\ActionColumn',
                'visibleButtons' => [
                    'view' => function ($model, $key, $index) {
                        return $model->status === 1 ? false : true;
                     },

                    'delete' => function ($model, $key, $index) {
                        return $model->status === 1 ? false : false;
                     },
                     
                    'update' => function ($model, $key, $index) {
                        return $model->status === 1 ? false : false;
                     },             

                ]
            ]


        ],
    ]); ?>
<?php Pjax::end(); ?></div>
